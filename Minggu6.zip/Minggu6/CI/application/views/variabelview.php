<html>
    <head><title>Controller dan View lebih dari 1 Variabel</title></head>
<body>
    <h2>Mengirim Data dari Controller ke View</h2>
    
    variabel1: <?php echo $variabel1;?><br/>
    variabel2: <?php echo $variabel2;?><br/>
</body>
</html>
